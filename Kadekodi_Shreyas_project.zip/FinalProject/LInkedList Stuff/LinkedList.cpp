
#include "LinkedList.hpp"
#include <iostream>
#include <string>
#include <ctime>
#include <ratio>
#include <chrono>
#include <fstream>

using namespace std;

inline LinkedList::LinkedList(){
    head=nullptr; //sets beginning to nullptr
    ofstream outFileI("StoreResultInsertLL.csv"); //used to input data, read it all
    ofstream outFileS("StoreResultSearchLL.csv");
    ifstream inputFile("dataSetB.csv");
    if(!outFileI.is_open()){
        cout<<"1"<<endl;
    }
    if(!outFileS.is_open()){
        cout<<"2"<<endl;
    }
    if(!inputFile.is_open()){
        cout<<"3"<<endl;
        inputFile.open("C:\\Users\\Shreyas\\Documents\\FinalProject\\dataSetA.csv");
    }
    string line;
    int i=1;
    if(inputFile.is_open()){
        while(getline(inputFile,line,',')){
            testData[i]=stoi(line);
            i++;
        }
    }
    int j=0;
    chrono::high_resolution_clock::time_point t1 = chrono::high_resolution_clock::now();
    chrono::high_resolution_clock::time_point t2;
    chrono::duration <double> span;
    int g=0;
    for(int y=0;y<40000;y++){
        int x=testData[y];
        insertNode(x);
        if(j!=0&j%100==0){
             t2= chrono::high_resolution_clock::now();
             span= chrono::duration_cast<chrono::duration<double>>(t2 - t1); //used to measure the difference in time
             insert[g]=(span.count()/100);
             g++;
             t1= chrono::high_resolution_clock::now();
        }
        j++;
    }
    chrono::high_resolution_clock::time_point t3;
    chrono::high_resolution_clock::time_point t4;
    chrono::duration <double> span2;
    j=0;
    for(int r=0;r<400;r++){
        t3 = chrono::high_resolution_clock::now();
        for(int i=0;i<100;i++){
            int y=rand()%100+r*100;
            Node *temp=searchNode(testData[y]);
        }
        t4 = chrono::high_resolution_clock::now();
        span2 = chrono::duration_cast<chrono::duration<double>>(t4 - t3);
        search[j]=(span2.count()/100);
        j++;
    }
    for(int i=0;i<400;i++){ //prints to file
        outFileI<<insert[i]<<endl;
        outFileS<<search[i]<<endl;
    }
}
inline void LinkedList::insertNode(int key){
    Node *temp=new Node{key,nullptr};
    if(!head){ //if the linkedlist is empty
        head=temp;
        return;
    }
    Node *n1=head;
    while(n1->next){ //goes through LL
        n1=n1->next;
    }
    n1->next=temp; //inserts at the end
}

inline void LinkedList::displayLL(){
    Node* l1=head; //goes though all nodes, prints their values
    while(l1){
        cout<<l1->key<<" -> ";
        l1=l1->next;
    }
}


inline Node *LinkedList::searchNode(int key){
    Node* l1=head;
    while(l1){
        if(l1->key==key){ //goes through LL, checks if key is the same
            return l1; //if key is the same
        }
        l1=l1->next; //keeps cycling
    }
    return nullptr;
}

// int main(){
//     LinkedList H;
// }
