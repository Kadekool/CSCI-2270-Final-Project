#ifndef LINKEDLIST_HPP
#define LINKEDLIST_HPP
#include <string>
#include <ctime>
#include <ratio>
#include <chrono>
#include <fstream>
using namespace std;



struct Node{
    int key;
    Node* next;
};

class LinkedList
{
    private:
        Node* head;
        int testData[40000];
        float insert[400];
        float search[400];
    public:
        LinkedList();
        void displayLL();
        void insertNode(int key);
        Node* searchNode(int key);
};

#endif
