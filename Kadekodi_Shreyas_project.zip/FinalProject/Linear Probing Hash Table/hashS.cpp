#include "hashS.hpp"
#include <iostream>
#include <chrono>
#include <math.h>
#include <fstream>

using namespace std;

node HashTable::createNode(int key){
    node *temp=new node{}; 
    temp->key=key;
    return *temp; //creates and returns a node
}

HashTable::HashTable(int bsize){
    table =new node[bsize]; //creates the array,intiialized in the heap
    tableSize=bsize;
    for(int i=0;i<bsize;i++){
        table[i]=createNode(0);
    }
    ofstream outFileI("StoreInsertHashS.csv");
    ofstream outFileS("StoreSearchHashS.csv");
  ofstream outFileC("StoreCollisions.csv");
    ifstream inputFile("dataSetB.csv");
    if(!outFileI.is_open()){
        cout<<"1"<<endl;
    }
    if(!outFileS.is_open()){
        cout<<"2"<<endl;
    }
    if(!inputFile.is_open()){
        cout<<"3"<<endl;
        inputFile.open("C:\\Users\\Shreyas\\Documents\\FinalProject\\dataSetA.csv");
    }
    string line;
    int i=0;
    if(inputFile.is_open()){
        while(getline(inputFile,line,',')){
            testData[i]=stoi(line);
            i++;
        }
    }
    int j=0;
    chrono::high_resolution_clock::time_point t1 = chrono::high_resolution_clock::now();
    chrono::high_resolution_clock::time_point t2;
    chrono::duration <double> span;
    int g=0;
    float storeCol=0;
    for(int y=0;y<40000;y++){
        int x=testData[y];
        //cout<<x<<endl;
        insertItem(x);
        if(j!=0&j%100==0){
             t2= chrono::high_resolution_clock::now();
             span= chrono::duration_cast<chrono::duration<double>>(t2 - t1);
             //cout<<span.count()<<endl;
             insert[g]=(span.count()/100);
             float Col=getNumOfCollision();
             collisions[g]=((Col-storeCol)/100);
             g++;
             t1= chrono::high_resolution_clock::now();
        }
        j++;
    }
    numOfcolision=0;
    //cout<<"table[0]: "<<table[0].key<<endl;
    chrono::high_resolution_clock::time_point t3;
    chrono::high_resolution_clock::time_point t4;
    chrono::duration <double> span2;
    j=0;
    storeCol=0;
    //cout<<numOfcolision<<endl;
    for(int r=0;r<400;r++){
        //cout<<"r: "<<r<<endl;
        t3 = chrono::high_resolution_clock::now();
        for(int i=0;i<100;i++){
            int y=rand()%100+r*100;
            node *temp=searchItem(testData[y]);
        }
        t4 = chrono::high_resolution_clock::now();
        span2 = chrono::duration_cast<chrono::duration<double>>(t4 - t3);
        float Col=getNumOfCollision();
        //cout<<Col<<endl;
        collisions[r+400]=((Col-storeCol)/100);
        storeCol=Col;
        search[j]=(span2.count()/100);
        j++;
    }
    //cout<<"Printing"<<endl;
    for(int i=0;i<400;i++){
        outFileI<<insert[i]<<endl;
        outFileS<<search[i]<<endl;
        outFileC<<collisions[i]<<endl;
    }
    for(int i=400;i<800;i++){
        outFileC<<collisions[i]<<endl;
    }
}


bool HashTable::insertItem(int key){
    int hashed=hashFunction(key);
    node check=createNode(key);
    if(table[hashed].key==0){
        table[hashed].key=key; //if the array is empty in the given location
    }else{
        node *temp=&table[hashed];
        while(temp){
            if(temp!=&table[tableSize-1]){
                temp=temp+1; //if the end of the array has not been reached
            }else{
                temp=&table[0]; //at the end of the array, put back at the beginning
            }
            numOfcolision++;
            if(temp){
                if(temp=&table[hashed-1]){
                    return false; //if the entire arrayhas been parsed
                }
            }
        }
        temp=&check;
    }
    return true;
}

unsigned int HashTable::hashFunction(int key){
    int hashed=key%tableSize;
    return hashed;
}

void HashTable::printTable(){
    for(int i=0;i<40000;i++){
        cout<<table[i].key<<" ";
    }
}
    
int HashTable::getNumOfCollision(){
    return numOfcolision;
}

node* HashTable::searchItem(int key){
    int hashed=hashFunction(key);
    if(table[hashed].key==0){
        return nullptr; 
    }else{
        int counter=0;
        int temp=hashed;
        do{
            if(table[hashed].key==key)
                return &table[hashed];
            if(hashed!=tableSize-1){
                hashed++;
            }else{
                hashed=0;
            }
            counter++;
            numOfcolision++;
        }while(hashed!=temp);  
    }
    return nullptr;
}

