#include "hashQ.cpp"

int main(){
    HashTable H(40000);
}