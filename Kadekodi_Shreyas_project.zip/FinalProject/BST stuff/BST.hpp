#ifndef BST_HPP
#define BST_HPP
#include <string>
#include <chrono> 
using namespace std;

struct Node{
        int key;
        Node* left;
        Node* right;
    };

class BST{
    
    private:

    Node* root;
    int testData[40000];
    float insert[400];
    float search[400];

    public:
    BST();
    void insertNode(int key);
    Node* searchNode(int key);
    void display();
    void print2DUtilHelper(Node *currNode, int space);
};

#endif