#include "BST.hpp"
#include <iostream>
#include <string>
#include <ctime>
#include <ratio>
#include <chrono>
#include <fstream>
inline BST::BST(){
    root=nullptr;
    ofstream outFileI("StoreResultInsertBST.csv");
    ofstream outFileS("StoreResultSearchBST.csv");
    ifstream inputFile("dataSetB.csv");
    if(!outFileI.is_open()){
        cout<<"1"<<endl;
    }
    if(!outFileS.is_open()){
        cout<<"2"<<endl;
    }
    if(!inputFile.is_open()){
        cout<<"3"<<endl;
        inputFile.open("C:\\Users\\Shreyas\\Documents\\FinalProject\\dataSetA.csv");
    }
    string line;
    int i=0;
    if(inputFile.is_open()){
        while(getline(inputFile,line,',')){
            testData[i]=stoi(line);
            i++;
        }
    }
    //cout<<"here"<<endl;
    int j=0;
    chrono::high_resolution_clock::time_point t1 = chrono::high_resolution_clock::now();
    chrono::high_resolution_clock::time_point t2;
    chrono::duration <double> span;
    int g=0;
    for(int y=0;y<40000;y++){
        int x=testData[y];
        insertNode(x);
        if(j!=0&j%100==0){
             t2= chrono::high_resolution_clock::now();
             span= chrono::duration_cast<chrono::duration<double>>(t2 - t1);
             //cout<<span.count()<<endl;
             insert[g]=(span.count()/100);
             g++;
             t1= chrono::high_resolution_clock::now();
        }
        j++;
    }
    //cout<<"root->val: "<<root->key<<endl;
    chrono::high_resolution_clock::time_point t3;
    chrono::high_resolution_clock::time_point t4;
    chrono::duration <double> span2;
    j=0;
    for(int r=0;r<400;r++){
        //cout<<"r: "<<r<<endl;
        t3 = chrono::high_resolution_clock::now();
        for(int i=0;i<100;i++){
            int y=rand()%100+r*100;
            //cout<<"testdata[y]:  "<<testData[y]<<endl;
            Node *temp=searchNode(testData[y]);
        }
        t4 = chrono::high_resolution_clock::now();
        span2 = chrono::duration_cast<chrono::duration<double>>(t4 - t3);
        //cout<<span2.count()<<endl;
        search[j]=(span2.count()/100);
        j++;
    }
    //cout<<"Printing"<<endl;
    for(int i=0;i<400;i++){
        outFileI<<insert[i]<<endl;
        outFileS<<search[i]<<endl;
    }
}
inline void BST::insertNode(int key){
    if(!root){
        //cout<<key<<endl;
        root=new Node{key,nullptr,nullptr};
        //cout<<root->key<<endl;
        return;
    }
    Node *t=root;
    while(t){
        if(t->key>key){
            if(t->left){
                t=t->left;
            }else{
                t->left=new Node{key,nullptr,nullptr};
                break;
            }
        }else{
            if(t->right){
                t=t->right;
            }else{
                t->right=new Node{key,nullptr,nullptr};
                break;
            }
        }
    }
}
inline Node* BST::searchNode(int key){
    Node *t=root;
    while(t){
        //cout<<"t: "<<t->key<<endl;
        while(t->key!=key){
            if(key<t->key){
                t=t->left;
            }else{
                t=t->right;
            }
        }
        if(t){
            if(t->key=key){
                return t;
            }
        }
    }
    return nullptr;
}

inline void BST::print2DUtilHelper(Node *currNode, int space){ //used exam code as a model, as well as the internet
    if (currNode == nullptr)
        return;
    space += 10;
    print2DUtilHelper(currNode->right, space);

    printf("\n");
    for (int i = 10; i < space; i++)
        printf(" ");
    printf("%d\n", currNode->key);
    print2DUtilHelper(currNode->left, space);
}

inline void BST::display(){
    print2DUtilHelper(root,1);
}

