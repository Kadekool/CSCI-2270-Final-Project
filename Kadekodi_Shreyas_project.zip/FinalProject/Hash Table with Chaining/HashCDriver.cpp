#include "hash.hpp"

int main(){
    HashTable N(40000);
}